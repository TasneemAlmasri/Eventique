<?php echo e($slot); ?>

<?php /**PATH E:\نسخ مشروع 1\eventiuqe1\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>