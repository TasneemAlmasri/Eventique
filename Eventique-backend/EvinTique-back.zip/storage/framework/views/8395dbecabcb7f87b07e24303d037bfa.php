<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\vscproject\نسخة الكل مع الاوردر كامل\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/header.blade.php ENDPATH**/ ?>